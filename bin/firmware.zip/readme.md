

# airrohr-firmware
* Note: config will be removed

# Instruction for update 
* Erase Flash (with Airrohr Flasher or FlashESP8266 see below)
* Run (on Windows) FlashESP8266
* Select com port
* Select blank_4MB.bin to erase
* Select firmware_xx.bin

# This firmware has
## New Sensors
* SEN5X
* CO2 on SCD30

## Plugins
* MQTT
* Static IP
* Power save


## WIFI 
* password is airrohrcfg




